﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class TicTacToe : Form
    {
        public TicTacToe()
        {
            InitializeComponent();
        }

        // Utworzenie 2 zmiennych całkowitych do przechowywania sumy wygranych każdego gracza
        int klikniec, wygraneX, wygraneO = 0;
        // Zmienna monitorująca czy gra została wygrana
        bool wygrana = false;

        // Mechanizm losowania pierwszego gracza
        //char pierwszyGracz = 'O', drugiGracz = 'X';

        private void button1_Click(object sender, EventArgs e)
        {
            // Sprawdzenie czy gra nadal trwa
            if (klikniec < 9 && wygrana != true)
            {
                // Instrukcje dla gracza 'O'
                if (klikniec % 2 == 0 && button1.Text == "")
                {
                    // Wpisanie 'O' w kliknięte pole i przestawienie rundy na następnego gracza
                    button1.Text = "O";
                    label1.Text = "Tura Gracza: X";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button1.Text == "O" && button2.Text == "O" && button3.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button1.Text == "O" && button4.Text == "O" && button7.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button1.Text == "O" && button5.Text == "O" && button9.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                }
                // Instrukcje dla gracza 'X'
                if (klikniec % 2 == 1 && button1.Text == "")
                {
                    // Wpisanie 'X' w kliknięte pole i przestawienie rundy na następnego gracza
                    button1.Text = "X";
                    label1.Text = "Tura Gracza: O";
                    klikniec++;

                    if (button1.Text == "X" && button2.Text == "X" && button3.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button1.Text == "X" && button4.Text == "X" && button7.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button1.Text == "X" && button5.Text == "X" && button9.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                }
                
                // Sprawdzenie czy remis i odkrycie przycisku nowej gry
                if (klikniec == 9 && wygrana == false)
                {
                    label1.Text = "        Remis";
                    button10.Visible = true;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Sprawdzenie czy gra nadal trwa
            if (klikniec < 9 && wygrana != true)
            {
                // Instrukcje dla gracza 'O'
                if (klikniec % 2 == 0 && button2.Text == "")
                {
                    // Wpisanie 'O' w kliknięte pole i przestawienie rundy na następnego gracza
                    button2.Text = "O";
                    label1.Text = "Tura Gracza: X";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button1.Text == "O" && button2.Text == "O" && button3.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button2.Text == "O" && button5.Text == "O" && button8.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                }
                // Instrukcje dla gracza 'X'
                if (klikniec % 2 == 1 && button2.Text == "")
                {
                    // Wpisanie 'X' w kliknięte pole i przestawienie rundy na następnego gracza
                    button2.Text = "X";
                    label1.Text = "Tura Gracza: O";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button1.Text == "X" && button2.Text == "X" && button3.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button2.Text == "X" && button5.Text == "X" && button8.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                }

                // Sprawdzenie czy remis i odkrycie przycisku nowej gry
                if (klikniec == 9 && wygrana == false)
                {
                    label1.Text = "        Remis";
                    button10.Visible = true;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Sprawdzenie czy gra nadal trwa
            if (klikniec < 9 && wygrana != true)
            {
                // Instrukcje dla gracza 'O'
                if (klikniec % 2 == 0 && button3.Text == "")
                {
                    // Wpisanie 'O' w kliknięte pole i przestawienie rundy na następnego gracza
                    button3.Text = "O";
                    label1.Text = "Tura Gracza: X";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button1.Text == "O" && button2.Text == "O" && button3.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button3.Text == "O" && button6.Text == "O" && button9.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button3.Text == "O" && button5.Text == "O" && button7.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                }
                // Instrukcje dla gracza 'X'
                if (klikniec % 2 == 1 && button3.Text == "")
                {
                    // Wpisanie 'X' w kliknięte pole i przestawienie rundy na następnego gracza
                    button3.Text = "X";
                    label1.Text = "Tura Gracza: O";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button1.Text == "X" && button2.Text == "X" && button3.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button3.Text == "X" && button6.Text == "X" && button9.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button3.Text == "X" && button5.Text == "X" && button7.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                }

                // Sprawdzenie czy remis i odkrycie przycisku nowej gry
                if (klikniec == 9 && wygrana == false)
                {
                    label1.Text = "        Remis";
                    button10.Visible = true;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Sprawdzenie czy gra nadal trwa
            if (klikniec < 9 && wygrana != true)
            {
                // Instrukcje dla gracza 'O'
                if (klikniec % 2 == 0 && button4.Text == "")
                {
                    // Wpisanie 'O' w kliknięte pole i przestawienie rundy na następnego gracza
                    button4.Text = "O";
                    label1.Text = "Tura Gracza: X";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button4.Text == "O" && button5.Text == "O" && button6.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button1.Text == "O" && button4.Text == "O" && button7.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                }
                // Instrukcje dla gracza 'X'
                if (klikniec % 2 == 1 && button4.Text == "")
                {
                    // Wpisanie 'X' w kliknięte pole i przestawienie rundy na następnego gracza
                    button4.Text = "X";
                    label1.Text = "Tura Gracza: O";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button4.Text == "X" && button5.Text == "X" && button6.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button1.Text == "X" && button4.Text == "X" && button7.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                }

                // Sprawdzenie czy remis i odkrycie przycisku nowej gry
                if (klikniec == 9 && wygrana == false)
                {
                    label1.Text = "        Remis";
                    button10.Visible = true;
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Sprawdzenie czy gra nadal trwa
            if (klikniec < 9 && wygrana != true)
            {
                // Instrukcje dla gracza 'O'
                if (klikniec % 2 == 0 && button5.Text == "")
                {
                    // Wpisanie 'O' w kliknięte pole i przestawienie rundy na następnego gracza
                    button5.Text = "O";
                    label1.Text = "Tura Gracza: X";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button1.Text == "O" && button5.Text == "O" && button9.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button4.Text == "O" && button5.Text == "O" && button6.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button2.Text == "O" && button5.Text == "O" && button8.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                }
                // Instrukcje dla gracza 'X'
                if (klikniec % 2 == 1 && button5.Text == "")
                {
                    // Wpisanie 'X' w kliknięte pole i przestawienie rundy na następnego gracza
                    button5.Text = "X";
                    label1.Text = "Tura Gracza: O";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button1.Text == "X" && button5.Text == "X" && button9.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button4.Text == "X" && button5.Text == "X" && button6.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button2.Text == "X" && button5.Text == "X" && button8.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                }

                // Sprawdzenie czy remis i odkrycie przycisku nowej gry
                if (klikniec == 9 && wygrana == false)
                {
                    label1.Text = "        Remis";
                    button10.Visible = true;
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Sprawdzenie czy gra nadal trwa
            if (klikniec < 9 && wygrana != true)
            {
                // Instrukcje dla gracza 'O'
                if (klikniec % 2 == 0 && button6.Text == "")
                {
                    // Wpisanie 'O' w kliknięte pole i przestawienie rundy na następnego gracza
                    button6.Text = "O";
                    label1.Text = "Tura Gracza: X";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button4.Text == "O" && button5.Text == "O" && button6.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button3.Text == "O" && button6.Text == "O" && button9.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                }
                // Instrukcje dla gracza 'X'
                if (klikniec % 2 == 1 && button6.Text == "")
                {
                    // Wpisanie 'X' w kliknięte pole i przestawienie rundy na następnego gracza
                    button6.Text = "X";
                    label1.Text = "Tura Gracza: O";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button4.Text == "X" && button5.Text == "X" && button6.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button3.Text == "X" && button6.Text == "X" && button9.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                }

                // Sprawdzenie czy remis i odkrycie przycisku nowej gry
                if (klikniec == 9 && wygrana == false)
                {
                    label1.Text = "        Remis";
                    button10.Visible = true;
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // Sprawdzenie czy gra nadal trwa
            if (klikniec < 9 && wygrana != true)
            {
                // Instrukcje dla gracza 'O'
                if (klikniec % 2 == 0 && button7.Text == "")
                {
                    // Wpisanie 'O' w kliknięte pole i przestawienie rundy na następnego gracza
                    button7.Text = "O";
                    label1.Text = "Tura Gracza: X";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button7.Text == "O" && button8.Text == "O" && button9.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button1.Text == "O" && button4.Text == "O" && button7.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button3.Text == "O" && button5.Text == "O" && button7.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                }
                // Instrukcje dla gracza 'X'
                if (klikniec % 2 == 1 && button7.Text == "")
                {
                    // Wpisanie 'X' w kliknięte pole i przestawienie rundy na następnego gracza
                    button7.Text = "X";
                    label1.Text = "Tura Gracza: O";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button7.Text == "X" && button8.Text == "X" && button9.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button1.Text == "X" && button4.Text == "X" && button7.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button3.Text == "X" && button5.Text == "X" && button7.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                }

                // Sprawdzenie czy remis i odkrycie przycisku nowej gry
                if (klikniec == 9 && wygrana == false)
                {
                    label1.Text = "        Remis";
                    button10.Visible = true;
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // Sprawdzenie czy gra nadal trwa
            if (klikniec < 9 && wygrana != true)
            {
                // Instrukcje dla gracza 'O'
                if (klikniec % 2 == 0 && button8.Text == "")
                {
                    // Wpisanie 'O' w kliknięte pole i przestawienie rundy na następnego gracza
                    button8.Text = "O";
                    label1.Text = "Tura Gracza: X";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button7.Text == "O" && button8.Text == "O" && button9.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button2.Text == "O" && button5.Text == "O" && button8.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                }
                // Instrukcje dla gracza 'X'
                if (klikniec % 2 == 1 && button8.Text == "")
                {
                    // Wpisanie 'X' w kliknięte pole i przestawienie rundy na następnego gracza
                    button8.Text = "X";
                    label1.Text = "Tura Gracza: O";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button7.Text == "X" && button8.Text == "X" && button9.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button2.Text == "X" && button5.Text == "X" && button8.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                }

                // Sprawdzenie czy remis i odkrycie przycisku nowej gry
                if (klikniec == 9 && wygrana == false)
                {
                    label1.Text = "        Remis";
                    button10.Visible = true;
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // Sprawdzenie czy gra nadal trwa
            if (klikniec < 9 && wygrana != true)
            {
                // Instrukcje dla gracza 'O'
                if (klikniec % 2 == 0 && button9.Text == "")
                {
                    // Wpisanie 'O' w kliknięte pole i przestawienie rundy na następnego gracza
                    button9.Text = "O";
                    label1.Text = "Tura Gracza: X";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button7.Text == "O" && button8.Text == "O" && button9.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button3.Text == "O" && button6.Text == "O" && button9.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                    if (button1.Text == "O" && button5.Text == "O" && button9.Text == "O")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: O";
                        wygraneO++;
                        label2.Text = "Wygrane O: " + wygraneO;
                    }
                }
                // Instrukcje dla gracza 'X'
                if (klikniec % 2 == 1 && button9.Text == "")
                {
                    // Wpisanie 'X' w kliknięte pole i przestawienie rundy na następnego gracza
                    button9.Text = "X";
                    label1.Text = "Tura Gracza: O";
                    klikniec++;

                    // Sprawdzenie czy gracz wygrał grę i zwiększenie liczby wygranych
                    if (button7.Text == "X" && button8.Text == "X" && button9.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button3.Text == "X" && button6.Text == "X" && button9.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                    if (button1.Text == "X" && button5.Text == "X" && button9.Text == "X")
                    {
                        wygrana = true;
                        button10.Visible = true;
                        label1.Text = "Wygrał Gracz: X";
                        wygraneX++;
                        label3.Text = "Wygrane X: " + wygraneX;
                    }
                }

                // Sprawdzenie czy remis i odkrycie przycisku nowej gry
                if (klikniec == 9 && wygrana != true)
                {
                    label1.Text = "        Remis";
                    button10.Visible = true;
                }
            }
        }

        // Implemetacja przycisku nowej gry
        private void button10_Click(object sender, EventArgs e)
        {
            // Zerowanie zmiennych
            klikniec = 0;
            button1.Text = "";
            button2.Text = "";
            button3.Text = "";
            button4.Text = "";
            button5.Text = "";
            button6.Text = "";
            button7.Text = "";
            button8.Text = "";
            button9.Text = "";
            wygrana = false;
            button10.Visible = false;
            label1.Text = "Tura Gracza: O";

            // Logika  losowania pierwszego gracza
            /*
            int seed = System.DateTime.Now.Millisecond;
            System.Random los = new Random(seed);
            if (los.Next(1, 100) % 2 == 1)
            {
                pierwszyGracz = 'O';
                drugiGracz = 'X';
                label1.Text = "Tura Gracza: O";
            }
            else
            {
                pierwszyGracz = 'X';
                drugiGracz = 'O';
                label1.Text = "Tura Gracza: X";
            }
            */
        }
    }
}
